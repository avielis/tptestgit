const BMIData = [
  { name: "Maigreur", color: "midnightblue", range: [0, 18.5] },
  { name: "Bonne santé", color: "green", range: [18.5, 25] },
  { name: "Surpoids", color: "lightcoral", range: [25, 30] },
  { name: "Obésité modérée", color: "orange", range: [30, 35] },
  { name: "Obésité sévère", color: "crimson", range: [35, 40] },
  { name: "Obésité morbide", color: "purple", range: 40 },
];
//console.log("IMC")

// IMC = poids en kg / taille² en m


document.getElementById("resultat").innerHTML= 0 + "<br>" + "En attente du résultat...";

function calculbutton() {

  var height = document.getElementById("taille").value
  var weight = document.getElementById("poids").value

  if (weight === "" || height === ""){
// if (height > 0 && weight > 0) {
//             // Calculer l'IMC
//             var imc = weight / (height * height);
//
            // Afficher le résultat
//             document.getElementById('result').innerHTML = 'Votre IMC est : ' + imc.toFixed(2);
//         } else {
//             // Afficher un message d'erreur si les valeurs ne sont pas valides
//             document.getElementById('result').innerHTML = 'Veuillez entrer des valeurs valides.';
//         }
//     }
   // Afficher un message d'erreur si les valeurs ne sont pas valides
    document.getElementById("resultat").innerHTML="Veuillez remplir les inputs";
    return;
  }

  const IMC = (weight / Math.pow(height / 100, 2)).toFixed(1);
  document.getElementById("resultat").innerHTML="votre IMC est : " + IMC;

  //console.log(IMC);

  const resultatIMC = calculerRangIMC(IMC);
  document.getElementById("resultatimc").innerHTML= resultatIMC

}

function calculerRangIMC(IMC) {
  for (let i = 0; i < BMIData.length; i++) {
    const category = BMIData[i]
    const minRange = category.range[0]
    const maxRange = category.range[1]

    if (minRange <= IMC && (maxRange === undefined || IMC < maxRange)) {
      return category.name
    }
  }
  return "entrer le vrai poid et la vrai taille";
}